import React,{useEffect} from "react";
// import { ArrowRight16 } from "@carbon/icons-react";
import  * as All from "@carbon/icons-react";

import { Link } from "react-router-dom";
import Line from "./../../../img/Homepage/ContentDriven/line.png";
import Cancer from "./../../../img/Homepage/ContentDriven/cancer.png";
import Science from "./../../../img/Homepage/ContentDriven/science.png";
import Rob from "./../../../img/Homepage/ContentDriven/rob.png";
import Stock from "./../../../img/Homepage/ContentDriven/stock.png";
import {connect} from 'react-redux';
import {newsRoomPageDataStart} from "../../../actions/index";

const CardVal = [
  {
    caption: "CAPTION",
    about: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus
  quam eu porta molestie. Fusce et vulputate metus, ac sagittis risus
  Nam maximus ex nec purus accumsan,eu congue lorem pellentesque.`,
  },
  {
    caption: "CAPTION",
    about: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc maximus quam eu porta molestie.`,
  },
];


const Icon = (props) => {
  const { iconName } = props;
  const icon = React.createElement(All[iconName]);
  return <>{icon}</>;
};

const Card = ({ caption, about, src, iconpass="ArrowLeft16" }) => (
  <div className="card">
    <div className="bx--col bx--no-gutter img">
      <img src={src} alt="" />
    </div>
    <div className="bx--col content">
      <div className="caption">
        <h6>{caption}</h6>
      </div>
      <div className="about">
        <p>{about}</p>
      </div>
      <div className="arrow">
        <Link to="#">
          {/* <All.ArrowRight16 /> */}
          <Icon iconName={iconpass}/>

        </Link>
      </div>
    </div>
  </div>
);



const ContentBotm = ({newsRoomPageDataStart,newsRoomData}) => {
  useEffect(() => {
    newsRoomPageDataStart();
  }, []);
  // const iconname = "ArrowRight16"
  // const icon = ("All." + `${iconname}` ) 

  // console.log(<`${}` />)
  
// let iconname= eval('({' + All.ArrowLeft16  + '})');  
// console.log(iconname,"iconname")
// let dummyData=JSON.parse(newsRoomData &&newsRoomData.caption_sub && newsRoomData &&newsRoomData.caption_sub[0])

//   let icon= <All.ArrowLeft16 />
//     console.log(typeof icon,"icontype");
//     let data=newsRoomData &&newsRoomData.caption_sub && newsRoomData &&newsRoomData.caption_sub[0].caption_icon
//     console.log(typeof data,"data");
//   console.log(newsRoomData &&newsRoomData.caption_sub,"newsRoomData");


 
  
  
      //  <Icon iconName={"SettingsAdjust32"}/>

  return (
    <div className="bx--grid-full-width bottom">

      <div className="bx--grid">
        <div className="bx--row">
          <div className="bx--col-lg-4 banner-bot">
            <h6>{newsRoomData && newsRoomData.newseoom_top_heading}</h6>
            <h4>{newsRoomData && newsRoomData.newseoom_heading}</h4>
            <p>{newsRoomData && newsRoomData.newseoom_description}</p>
          </div>
          <div className="bx--col card-bot">
            <div className="bx--row bx--no-gutter--left ">
              <div className="bx--col-lg-11 ">
                <Card
                  src={Line}
                  caption={newsRoomData && newsRoomData.caption_title}
                  about={newsRoomData && newsRoomData.caption_desc}
                  iconpass={newsRoomData && newsRoomData.caption_icon}

                />
              </div>
              <div className="bx--col-lg-5 bx--no-gutter">
                <Card
                  src={newsRoomData &&newsRoomData.caption_sub &&newsRoomData.caption_sub[0].caption_sub_image.url}
                  caption={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[0].caption_sub_heading}
                  about={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[0].caption_sub_description}
                  iconpass={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[0].caption_icon}
                />
              </div>
            </div>
            <div className="bx--row  ">
              <div className="bx--col">
                <div className="bx--row bx--no-gutter--left ">
                  <div className="bx--col-lg-8">
                    <Card
                      src={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[1].caption_sub_image.url}
                      caption={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[1].caption_sub_heading}
                      about={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[1].caption_sub_description}
                      iconpass={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[1].caption_icon}

                    />
                  </div>
                  <div className="bx--col-lg-8">
                    <Card
                      src={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[2].caption_sub_image.url}
                      caption={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[2].caption_sub_heading}
                      about={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[2].caption_sub_description}
                      iconpass={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[2].caption_icon}
                    />
                  </div>
                </div>
              </div>
              <div className="bx--col-lg-5 bx--no-gutter ">
                <Card
                  src={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[3].caption_sub_image.url}
                  caption={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[3].caption_sub_heading}
                  about={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[3].caption_sub_description}
                  iconpass={newsRoomData && newsRoomData.caption_sub &&newsRoomData.caption_sub[3].caption_icon}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = state => ({
  newsRoomData: state.landingPageReducer.newsRoomData
});

const mapDispatchToProps = (dispatch) => ({
  newsRoomPageDataStart: () => dispatch(newsRoomPageDataStart())
});


export default connect(mapStateToProps,mapDispatchToProps)(ContentBotm);
