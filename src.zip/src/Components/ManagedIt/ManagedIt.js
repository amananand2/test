import React from 'react';
import MainHeader from "../Homepage/Mainheader/MainHeader";
import { Grid, Row, Button } from "carbon-components-react";
import { ArrowDown20, ArrowRight16, ArrowLeft16 } from "@carbon/icons-react";
import headerimg from "./../../img/managedit/headerimg.png";
import { SystemsDevopsCode, University, OptimizeCashFlow_02, datacenterPakForSecurity, Servers } from "@carbon/pictograms-react";
import FooterBotm from '../Homepage/Footer/FooterBotm';
import bg1 from "./../../img/technologyservices/bg1.png";
import hardDrive from "./../../img/managedit/hardDrive.svg";




const ManagedIt = () => {
    return (
        <div className="managedit">
             <MainHeader/>
      <Grid className="bx--no-gutter" fullWidth>
                {/* section 1 starts*/}
                <div className="managedit__banner">
                    <Row className="managedit__banner_img" >
            <Grid>
            
           <div className="bx--col-lg-7 managedit__banner__content ">
                  {/* <Grid className="bx--offset-lg-3"> */}
                        <div className="managedit__header_content_icon">
                         <Servers stroke="#f4f4f4" />
                         </div>
                         <div className="managedit__header_content_heading">
                         <h1>Managed IT</h1>
                         </div>
                         <div className="managedit__header_content_para">
                         <p>Using managed IT services can free up your IT team to invest their valuable time in supporting your organization’s growth and fine-tuning existing systems. Whether you choose to use managed service providers (MSPs) only for specific, mundane tasks or to manage the bulk of your IT structure, leveraging managed IT services enables you to invest less time in repetitive IT tasks and more time towards business-critical objectives. MSPs can serve as the foundation for all your IT needs or focus solely on cybersecurity initiatives. You can also take an a la carte approach, selecting services as needed.</p>
                         </div>
                         <div className="managedit__header_content_button">
                            <Button renderIcon={ArrowDown20}>Learn more</Button>
                         </div>

                         <div className="managedit__header_content_downbutton">
                               <div className="arrow-left">
                                 <ArrowLeft16/>
                                </div>
                                  
                                <p>Technology Services</p>
                                 <div className="border"></div>
                                <p>Next Up: WORKFORCE ENABLEMENT</p>
                                 <div className="arrow-right">
                                 <ArrowRight16/>
                                </div>
                         </div>
                          {/* </Grid> */}
                        </div> 
                        <div className="bx--col-lg-8 bx--offset-lg-1">
                          {/* <img src={headerimg}/> */}
                          </div>
                   
                   </Grid>
                   </Row>
          </div>
                          {/* section 1 ends */}

 {/* section 2 starts*/}
 <div className="managedit_benefits">
      <Grid >
      <div className="bx--col-lg-10   managedit__benefits__heading">
        <h1>Benefits of Managed IT</h1>
      </div>
      </Grid>


       {/* first row */}
       <Grid>
          <Row>
          <div className="bx--col-lg-7 ">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  1
              </div>
              <p>Increased productivity and efficiency</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>Companies may be used to responding to and tracking issues reactively. However, after switching to an MSP, they may be surprised to learn how inefficient their prior management system really was.</p>
          </div>
          </div>

          <div className="bx--col-lg-7 bx--offset-lg-1 bx--no-gutter ">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  2
              </div>
              <p>Shared responsibilities and risks</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>An MSP’s goal is to fulfill their service contract—measuring, reporting, analyzing, and optimizing IT service operations, all to support business growth. They are willing to take leadership roles, reduce risk, improve efficiency, and bolster the entire technology culture. If a company retains its own technicians, they will introduce and provide training for new processes and technologies.</p>
          </div>
          </div>
          </Row>
      </Grid>

      {/* first row ends */}

      {/* second row starts */}
      <Grid>
          <Row>
          <div className="bx--col-lg-7">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  3
              </div>
              <p>Better comprehension of infrastructural needs</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>Data center services provide you with more opportunities to protect your organization from risks. Create your own disaster recovery sites, so you can maintain operations even during a catastrophic outage. Locate your disaster recovery site remotely to protect your assets even when your production location is put at physical risk. With a strategically placed recovery site and a comprehensive disaster recovery plan, you can bring your entire system back online in no time.</p>
          </div>
          </div>

          <div className="bx--col-lg-7 bx--offset-lg-1 bx--no-gutter">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  4
              </div>
              <p>Full-time IT department for less money</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>Many business owners prefer to be involved in proactive management. The problem, however, might be identifying the resources, budget, or access needed to stay ahead of issues. An MSP gives affordable support to business owners as well as their overworked IT staff, monitoring critical components for them, managing disaster recovery and data backup, providing network security and softw</p>
          </div>
          </div>
          </Row>
      </Grid>

      {/* second row ends */}

       {/* Third row starts */}
       <Grid>
          <Row>
          <div className="bx--col-lg-7">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  5
              </div>
              <p>Accessible historical data</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>An MSP's tools constantly monitor the capacity and performance of the database size, system space, and network bandwidth, as well as other resources. All of that information is then kept as historical data. Of course, clients can access and use this data in order to analyze performance trends in connection with a specific database or device. Consequently, they are able to make better decisions regarding future IT requirements.</p>
          </div>
          </div>

          <div className="bx--col-lg-7 bx--offset-lg-1 bx--no-gutter ">
          <div className="managedit__benefits__content__sixth__heading">
              <div className="box">
                  6
              </div>
              <p>Resource reallocation and an emphasis on the business’ core elements</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>Internal IT staff and business owners alike would rather concentrate on tasks such as improving operations or product development, activities that enhance the stream of revenue. For this reason, regular tasks may often be neglected, to the organization’s future detriment. MSP’s are even misrepresented as threats to the job security and operations of the full-time IT staff, whereas instead, the purpose of an MSP is to relieve the IT staff of run-of-the-mill maintenance, repetitious monitoring, and daily operational responsibilities.</p>
          </div>
          </div>
          </Row>
      </Grid>

      {/* Third row ends */}
 {/* fourth row starts*/}

      <Grid>
          <Row>
          <div className="bx--col-lg-7 ">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  7
              </div>
              <p>Timely update and patch management.</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>If the IT staff is too busy putting out fires, patch management often gets overlooked. This may expose an organization to the risk of downtime, vulnerabilities in security, and incidents unsupported by vendors because patches are outdated. MSP’s, however, will make sure software and patches are up-to-date.</p>
          </div>
          </div>

          <div className="bx--col-lg-7 bx--offset-lg-1 bx--no-gutter ">
          <div className="managedit__benefits__content__first__heading">
              <div className="box">
                  8
              </div>
              <p>Shared responsibilities and risks</p>
          </div>
          <div className="managedit__benefits__content__first__content">
          <p>Preventatively tracking and correcting problems means that downtime stemming from IT issues is either minimal or non-existent. A business would rarely be at risk of becoming unavailable, and customers will view its services as organized and reliable.</p>
          </div>
          </div>
          </Row>
      </Grid>
 {/* fourth row ends*/}

      </div>
         {/* section 2 ends*/}
          {/* section 3  starts*/}   
          <div className="develop__application">
                        <Grid>
                            <Row>
                                {/* left content  starts*/} 
                            <div className="bx--col-lg-8  ">
                             <div className="develop__application__heading ">
                                 <p>Incorporate Managed IT with Uvation</p>
                             </div>
                             <div className="develop__application__content ">
                                 <p>Uvation can help you choose the optimal managed IT solution for your infrastructure. Regardless of whether you need an MSP to manage the majority of your IT needs, just your security, or a mixture of both, Uvation can use your business’ goals to guide you to the most effective solution. Contact Uvation today to find the managed IT solution that maximizes both IT efficacy and your organization’s growth.</p>
                             </div>
                            </div>
                                {/* left content ends*/}
                                {/* right content starts*/}
                                <div className="bx--col-lg-7 bx--offset-lg-1 develop__application__image">
                                    <img src={bg1}/>
                                        <div class="book_consultation">
                                        <p>Book a Consultation</p>
                                        </div>
                                </div>
                                {/* right content ends*/}
                            </Row>
                           
                            
                        </Grid>
                      

                    </div>
                    {/* section 3  ends*/}

                    {/* section 4  starts*/}
                    <div className="managedit_works">
                   <Grid>
                       <Row>
                       <div className="bx--col-lg-16  managedit_works_heading">
                        <p>How Managed IT Works</p>
                        <div className="bx--col-lg-16 managedit_works_heading_border">
                        </div>
                       </div>
                    {/* Row 1  starts*/}
                   
                       <div className="bx--col-lg-16">
                           <Row>
                       <div className="bx--col-lg-5  bx--no-gutter   managedit_works_subheading_one_left">
                           <p>TRADITIONAL SERVICES</p>
                       </div>
                       <div className="bx--col-lg-10 bx--offset-lg-1 bx--no-gutter    managedit_works_subheading_one_right">
                           <p>Traditional Managed Service Providers (MSP) are the standard go-to for assistance with issues such as a network interruption or failure.</p>
                       </div>
                       </Row>

                       <div className= "bx--col-lg-16 managedit_works_subheading_border">
                        </div>
                       </div>
                      

                        <div className="bx--col-lg-5 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>01</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Problem and Incident Management:</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="bx--no-gutter managedit_works_subheading_content_desc">
                         <p>This refers to the main framework used to restore normal service quickly and efficiently. However, traditional MSPs would not normally perform time-heavy services such as the analysis of the root cause of a problem. Root cause analysis is often included in next-gen managed services, and can be a critical tool in diagnosing network failure.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-5 bx--no-gutter bx--offset-lg-1 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>02</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>System Administration:</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="managedit_works_subheading_content_desc">
                         <p>This involves completely managing and optimizing a customer’s technology infrastructure. When properly implemented, it allows IT staff to be able to concentrate their focus strategically, honing in on the most essential areas.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-4 bx--no-gutter bx--offset-lg-1 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>03</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>System Administration:</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="managedit_works_subheading_content_desc">
                         <p>This refers to comprehensively planning and executing software updates in such a manner as to guarantee that patches have been properly scheduled, tested, and deployed quickly without an adverse impact on end-users.</p>
                        </div>
                        </div>
                    {/* Row 1  starts*/}
                   
                    {/* Row 2  starts*/}

                        
                     
                        <div className="bx--col-lg-16">
                        <div className= "bx--col-lg-16 managedit_works_subheading_border">
                        </div>
                           <Row>
                       <div className="bx--col-lg-5  bx--no-gutter   managedit_works_subheading_two_left">
                           <p>ADVANCED SERVICES</p>
                       </div>
                       <div className="bx--col-lg-10 bx--offset-lg-1 bx--no-gutter    managedit_works_subheading_two_right">
                           <p>While traditional managed services are mainly reactive, advanced managed services are proactive in that they work to anticipate issues before they happen, attempting to prevent the network from failing or suffering interruption altogether.</p>
                       </div>
                       </Row>

                       <div className= "bx--col-lg-16 managedit_works_subheading_two_borderdown">
                        </div>
                       </div>

                       <div className="bx--col-lg-5 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>01</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Enhanced Monitoring</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="bx--no-gutter managedit_works_subheading_content_desc">
                         <p>Isolating potential issues is the goal of enhanced monitoring. that way they can be addressed before they become all-out incidents. The standard practice is to position a device inside the network to allow the system to monitor, diagnose, and report information pertaining to the status of the network.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-5 bx--no-gutter bx--offset-lg-1 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>02</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Service Management</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="managedit_works_subheading_content_desc">
                         <p>This service provides sturdy reporting, notifications, and communications to provide real-time visuals of the protected systems, as well as a detailed tracking of life cycles of every service ticket or incident.</p>
                        </div>
                        </div>
                    {/* Row 2 ends*/}
                    {/* Row 3 starts*/}
                    <div className="bx--col-lg-16">
                        <div className= "bx--col-lg-16 managedit_works_subheading_border">
                        </div>
                           <Row>
                       <div className="bx--col-lg-5  bx--no-gutter   managedit_works_subheading_two_left">
                           <p>NEXT-GEN MANAGED SERVICES</p>
                       </div>
                       <div className="bx--col-lg-10 bx--offset-lg-1 bx--no-gutter    managedit_works_subheading_two_right">
                           <p>There has been a higher demand for the option to customize programs, provide enhanced customer service and sturdier relationships with MSPs. So next-gen managed services created the response to this demand, and then naturally spurned an evolution of the managed services sector. Next-gen MSPs work to comprehend the needs of each client, gaining a deeper understanding of their performance indicators, business goals, resources, and core technologies, rather than just marketing and selling predefined packages. That way they can construct a customized package for each client. Next-gen Managed Services can include:</p>
                       </div>
                       </Row>

                       <div className= "bx--col-lg-16 managedit_works_subheading_two_borderdown">
                        </div>
                       </div>

                       <div className="bx--col-lg-5 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>01</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Client Success Advocate</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="bx--no-gutter managedit_works_subheading_content_desc">
                         <p>A Client Success Advocate (CSA) plays a crucial role in any next-gen MSP program. The CSA bears responsibility for the success of a MSP-client relationship. The CSA will engage fully with the IT operations and business teams to promote healthy communication and a workflow in which all are able to collaborate.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-5 bx--no-gutter bx--offset-lg-1 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>02</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Enterprise Lifecycle Management (ELM)</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="managedit_works_subheading_content_desc">
                         <p>A lifecycle program refers to the means by which a next-gen MSP brings a technology roadmap to life. Basically, a lifecycle program provides an understanding of platforms and technologies, both new and existing, and how or when an organization can benefit from their use. Really, it’s all about making technology empower a business.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-4 bx--no-gutter bx--offset-lg-1 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>04</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Enterprise Adoption Management:</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="managedit_works_subheading_content_desc">
                         <p>This service provides sturdy reporting, notifications, and communications to provide real-time visuals of the protected systems, as well as a detailed tracking of life cycles of every service ticket or incident.</p>
                        </div>
                        </div>

                        <div className="bx--col-lg-5 managedit_works_subheading_content">
                         <div className=" managedit_works_subheading_content_number">
                             <p>04</p>
                         </div>
                         <div className="managedit_works_subheading_content_heading">
                             <p>Enterprise Security Audit</p>
                         </div>

                         <div className="managedit_works_subheading_content_icon">
                             <img src={hardDrive}/>
                         </div>

                         <div className="bx--no-gutter managedit_works_subheading_content_desc">
                         <p>A Client Success Advocate (CSA) plays a crucial role in any next-gen MSP program. The CSA bears responsibility for the success of a MSP-client relationship. The CSA will engage fully with the IT operations and business teams to promote healthy communication and a workflow in which all are able to collaborate.</p>
                        </div>
                        </div>


                    {/* Row 3 ends*/}
                       </Row>
                   </Grid>
                   </div>
                    {/* section 4  ends*/}
                    {/* section 5  starts*/}
                    <div className="managedit_services">
         <div className="managedit_services_heading">
           <h1>How to Find a Managed IT Solution</h1>
           <p>The success of any business or enterprise, no matter its size or what sector it belongs to, depends partly on the successful incorporation of IT operations into its workspace. The majority of organizations look to MSP’s to help them implement and manage critical IT resources. The following are some practical steps to take when seeking a partnership with an MSP.</p>
       </div>
       <Grid>
           <Row>
               <div className="bx--col-lg-5 managedit_services_content">
                   <div className="managedit_services_content_img">
                   <OptimizeCashFlow_02 stroke="#f4f4f4" />
                  </div>
                  <div className="managedit_services_content_heading">
                      <p>1. IDENTIFY BUSINESS REQUIREMENTS</p>
                   </div>
                   <div className="managedit_services_content_para">
                      <p>Analyze the needs of the company prior to price comparing. Most MSP’s provide a wide selection of services beneficial to a business. They may offer communication tools to make teams more productive, or back-end cyber-security technologies and policies to protect a network from cyber-threats, and so forth. Implementing some of the technological needs of a business is not an easy task. Therefore, it's wise to leave IT management in the hands of capable specialists. A managed IT service provider will ensure that all the technological needs of a business workspace are filled.</p>
                   </div>     
               </div>

               <div className="bx--col-lg-5 managedit_services_content_second">  
                   <div className="managedit_services_content_second_img">
                   <OptimizeCashFlow_02 stroke="#f4f4f4" />
                  </div>
                  <div className="managedit_services_content_second_heading">
                      <p>2. LOCATE PARTNERS WHO MEET THE REQUIREMENTS</p>
                   </div>
                   <div className="managedit_services_content_second_para">
                      <p>After identifying the business requirements, start researching and analyzing the different offers and skills MSP’s provide. Even though most organizations prefer to work with MSP’s with knowledge specific to the industry, it is more important to work with a provider who is aware of the impact of technology on business outcomes, because their view of technology will be more comprehensive, providing powerful insights into ways to optimize IT investments.</p>
                   </div>     
               </div>
               <div className="bx--col-lg-5 managedit_services_content_second">  
                   <div className="managedit_services_content_second_img">
                   <OptimizeCashFlow_02 stroke="#f4f4f4" />
                  </div>
                  <div className="managedit_services_content_second_heading">
                      <p>3. EVALUATE PROVIDERS BY EXPERTISE AND CAPABILITY</p>
                   </div>
                   <div className="managedit_services_content_second_para">
                      <p>When locating a managed IT service provider, consider seven key capabilities that will reveal the extent of their knowledge and experience and provide a better idea of their approach to managing technology environments. These will be discussed in the following section.</p>
                   </div>     
               </div>
           </Row>
       </Grid>

      

         </div>
                    {/* section 5 ends*/}
                    {/* section 6 starts*/}
                    <div className="uvation_solution">
                        <Grid>
                            <Row>
                            <div className="bx--col-lg-16 ">
                        <p className="uvation_solution_heading">How Managed IT Works</p>
                            <p className="bx--col-lg-8 bx--no-gutter uvation_solution_subheading">At Uvation, we understand that your organization has to meet a certain threshold of safety and efficiency. Therefore, we make a thorough, comprehensive assessment of your needs, top to bottom.</p>
                       </div>
                    {/* first row starts*/}
                       <div className="bx--col-lg-16 uvation_solution_content">
                       <Row>
                           <div className="bx--col-lg-5 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Uvation’s Consultative Discovery Phase</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>Analyze the needs of the company prior to price comparing. Most MSP’s provide a wide selection of services beneficial to a business. They may offer communication tools to make teams more productive, or back-end cyber-security technologies and policies to protect a network from cyber-threats, and so forth. Implementing some of the technological needs of a business is not an easy task. Therefore, it's wise to leave IT management in the hands of capable specialists. A managed IT service provider will ensure that all the technological needs of a business workspace are filled.</p>
                            </div>
                           </div>

                           <div className="bx--col-lg-5 bx--offset-lg-1 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Comprehensive IT as a Service</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>As we gain a full understanding of your business, we shift from the discovery phase to the provision of services. One size does not fit all. Therefore, our portfolio includes every facet of a comprehensive IT as a service offering, allowing us to pick and choose what you need, and then fine-tune each offering until it provides an ideal fit. This can include a diverse assortment of managed IT services. Some of the most common include network, security, and data center management, as well as workplace enablement, and a complete technology vendor management program.</p>
                            </div>
                           </div>

                           <div className="bx--col-lg-4 bx--offset-lg-1 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Network Management</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>Uvation’s portfolio of providers can custom-craft a wide area network (WAN) or software-defined wide area network (SD-WAN) according to your commercial and technical needs. Our offerings combine automation and analytics to empower your business to implement networks using different carriers—or even countries—to support your cloud or hybrid cloud architecture. Our network management solutions can help you reduce downtime, make network management simpler, and give you the flexibility to facilitate growth</p>
                            </div>
                           </div>
                           </Row>
                    {/* first row ends*/}

                    {/* second row starts*/}
                           
                           <Row>
                           <div className="bx--col-lg-5 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Uvation’s Consultative Discovery Phase</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>Analyze the needs of the company prior to price comparing. Most MSP’s provide a wide selection of services beneficial to a business. They may offer communication tools to make teams more productive, or back-end cyber-security technologies and policies to protect a network from cyber-threats, and so forth. Implementing some of the technological needs of a business is not an easy task. Therefore, it's wise to leave IT management in the hands of capable specialists. A managed IT service provider will ensure that all the technological needs of a business workspace are filled.</p>
                            </div>
                           </div>

                           <div className="bx--col-lg-5 bx--offset-lg-1 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Comprehensive IT as a Service</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>As we gain a full understanding of your business, we shift from the discovery phase to the provision of services. One size does not fit all. Therefore, our portfolio includes every facet of a comprehensive IT as a service offering, allowing us to pick and choose what you need, and then fine-tune each offering until it provides an ideal fit. This can include a diverse assortment of managed IT services. Some of the most common include network, security, and data center management, as well as workplace enablement, and a complete technology vendor management program.</p>
                            </div>
                           </div>

                           <div className="bx--col-lg-4 bx--offset-lg-1 bx--no-gutter uvation_solution_subcontent">
                           <div className="uvation_solution_subcontent_icon">
                                <OptimizeCashFlow_02 stroke="#000000" />
                            </div>
                            <div className="uvation_solution_subcontent_heading">
                                <p>Network Management</p>
                            </div>
                            <div className="uvation_solution_subcontent_desc">
                                <p>Uvation’s portfolio of providers can custom-craft a wide area network (WAN) or software-defined wide area network (SD-WAN) according to your commercial and technical needs. Our offerings combine automation and analytics to empower your business to implement networks using different carriers—or even countries—to support your cloud or hybrid cloud architecture. Our network management solutions can help you reduce downtime, make network management simpler, and give you the flexibility to facilitate growth</p>
                            </div>
                           </div>
                           </Row>

                       </div>
                    {/* second row ends*/}

                            </Row>
                        </Grid>
                    </div>
                    {/* section 6 ends*/}

                       {/* section 7 starts*/}

           <div className="chat__application">
                        <Grid >
                            <Row >
                                {/* left content  starts*/} 
                            <div className="bx--col-lg-7 ">
                             <div className="chat__application__heading ">
                                 <p>Chat with an Uvation expert for a 30-minute strategy session at no cost</p>
                             </div>
                             <div className="chat__application__content ">
                                 <p>Get in touch for a consultation call or answer to any questions you might have.</p>
                             </div>
                            </div>
                                {/* left content ends*/}
                                {/* right content starts*/}
                                <div className="bx--col-lg-8 bx--offset-lg-1 chat__application__image">
                                    <img src={bg1}/>
                                        <div class="book_consultation">
                                        <p>Book a Consultation</p>
                                        </div>
                                </div>
                                {/* right content ends*/}
                            </Row>
                           
                            
                        </Grid>
                      

                    </div>



                    {/* section 7 ends*/}  
                          <FooterBotm/>
       </Grid>
        </div>
    )
}

export default ManagedIt
