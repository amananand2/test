import { Button, Column, Grid, Row } from 'carbon-components-react';
import React from 'react';
import headerBg from './../../img/cybersecurity/header.svg';
import bottomBg from './../../img/cybersecurity/bottom.png';
import managed from './../../img/cybersecurity/managed.png';
import soc from './../../img/cybersecurity/soc.png';
import {
  ArrowDown20,
  ArrowRight16,
  ArrowRight20,
  Chat16,
  IbmSecurity24,
  Launch16,
  Phone16,
} from '@carbon/icons-react';
import MainHeader from '../Homepage/Mainheader/MainHeader';
import { SystemsDevopsCode } from '@carbon/pictograms-react';
import { Link } from 'react-router-dom';
import FooterBotm from '../Homepage/Footer/FooterBotm';

const CybersecurityLanding = () => {
  return (
    <div className='cybersecurity'>
      <MainHeader />
      <Grid
        fullWidth
        style={{
          backgroundImage: `url(${headerBg})`,
          backgroundSize: 'cover',
          backgroundrepeat: 'no-repeat',
          backgroundPosition: 'center center',
        }}
      >
        <Row className='cybersecurity__banner'>
          <IbmSecurity24 />

          <Column lg={16} className='title'>
            <p>cybersecurity</p>
          </Column>
          <Column lg={12} className='heading'>
            <h1>Prepare and react with speed, agility and common purpose</h1>
          </Column>
          <Column lg={10} className='subheading'>
            <p>
              According to one study of Fortune 1000 companies from 2020, 54% of
              organizations are missing tactics to respond to even the early
              stages of a cyberattack.* The study found that 67% of
              organizations have seen successful data exfiltration tactics used
              against them and less than 10% of attacks even generate an alert.
            </p>
          </Column>
          <Column lg={10}>
            <div className='learnmore'>
              <Button renderIcon={ArrowDown20}>See more</Button>

              <Button renderIcon={ArrowRight20} kind='ghost'>
                Contact Us
              </Button>
            </div>
          </Column>
        </Row>
      </Grid>

      {/* image rows */}
      <Grid fullWidth className='cybersecurity__cardbox'>
        <Row condensed>
          <Column lg={8}>
            <div
              className='cardbox__img'
              style={{
                backgroundImage: `url(${soc})`,
                backgroundSize: 'cover',
                backgroundrepeat: 'no-repeat',
                backgroundPosition: 'center center',
              }}
            ></div>
          </Column>
          <Column lg={8}>
            <Column lg={{ span: 10, offset: 3 }}>
              <div className='card'>
                <SystemsDevopsCode stroke='#f4f4f4' />
                <div className='card__heading'>
                  <h3>SOC as a Service</h3>
                </div>
                <div className='card__para'>
                  <p>
                    For years, companies of all sizes have struggled to
                    implement a successful cybersecurity strategy. Several
                    factors have contributed to their difficulties, including a
                    widespread shortage of cybersecurity professionals, a need
                    for increasingly complex business computing environments,
                    and a constantly evolving threat landscape.
                  </p>
                </div>
                <div className='card__button'>
                  <Button as={Link} to='#' renderIcon={Launch16}>
                    Learn more
                  </Button>
                </div>
              </div>
            </Column>
          </Column>

          <Column lg={8}>
            <Column lg={{ span: 10, offset: 3 }}>
              <div className='card'>
                <SystemsDevopsCode stroke='#f4f4f4' />
                <div className='card__heading'>
                  <h3>Managed Security</h3>
                </div>
                <div className='card__para'>
                  <p>
                    Managed security is a cost-effective way to keep your
                    company safe. Instead of hiring an in-house security team,
                    you can rely on Uvation’s expertise to design, deploy, and
                    manage your security infrastructure. Expand your security
                    operations to protect your company from the latest cyber
                    threats through must-have security technologies, key
                    expertise, and 24/7 support.
                  </p>
                </div>
                <div className='card__button'>
                  <Button as={Link} to='#' renderIcon={Launch16}>
                    Learn more
                  </Button>
                </div>
              </div>
            </Column>
          </Column>
          <Column lg={8}>
            <div
              className='cardbox__img'
              style={{
                backgroundImage: `url(${managed})`,
                backgroundSize: 'cover',
                backgroundrepeat: 'no-repeat',
                backgroundPosition: 'center',
              }}
            ></div>
          </Column>

          <Column lg={8}>
            <div
              className='cardbox__img'
              style={{
                backgroundImage: `url(${soc})`,
                backgroundSize: 'cover',
                backgroundrepeat: 'no-repeat',
                backgroundPosition: 'center center',
              }}
            ></div>
          </Column>
          <Column lg={8}>
            <Column lg={{ span: 10, offset: 3 }}>
              <div className='card'>
                <SystemsDevopsCode stroke='#f4f4f4' />
                <div className='card__heading'>
                  <h3>Incident Response</h3>
                </div>
                <div className='card__para'>
                  <p>
                    In the event of a data breach or cyberattack, you need a
                    protocol to protect your assets and shore up your defenses.
                    Managed security service providers like Uvation can empower
                    your company with a full set of tools and processes for
                    responding to cyber incidents, so you can minimize risk and
                    place your company on the fast-track to recovery. Security
                    incidents are no longer a question of “if,” but “when.” A
                    comprehensive incident response program is an essential part
                    of doing business in today’s connected world.
                  </p>
                </div>
                <div className='card__button'>
                  <Button as={Link} to='#' renderIcon={Launch16}>
                    Learn more
                  </Button>
                </div>
              </div>
            </Column>
          </Column>
        </Row>
      </Grid>

      {/* get in touch */}
      <Grid
        fullWidth
        className='cybersecurity__getinTouch'
        style={{
          backgroundImage: `linear-gradient(90deg,#010101,#010101E1,#00000000),url(${bottomBg})`,
          backgroundSize: 'cover',
          backgroundrepeat: 'no-repeat',
          backgroundPosition: 'center center',
        }}
      >
        <Row condensed>
          <Column lg={8}>
            <Column lg={{ span: 13, offset: 3 }} sm={16}>
              <div className='cybersecurity__getinTouch__content'>
                <div className='heading'>
                  <h2>Get in touch with us</h2>
                </div>
                <div className='slogenLine'>
                  <p>Threats never sleep. Neither do we.</p>
                </div>
                <Column lg={{ span: 9 }} className='subheading'>
                  <p>
                    Get in touch for a consultation call or answer to any
                    questions you might have.
                  </p>
                </Column>
                <div className='getInbutton'>
                  <Button className='lrg-btn' renderIcon={Phone16}>
                    Call Us
                  </Button>
                  <Button kind='ghost' renderIcon={Chat16}>
                    Live chat
                  </Button>
                </div>
              </div>
            </Column>
          </Column>
          <Column lg={8}>
            <div className='sendus'>
              <div className='largeBtnSet'>
                <Button
                  as={Link}
                  to='#'
                  renderIcon={ArrowRight16}
                  size='xl'
                  className='left'
                >
                  Send us a message
                </Button>
                <Button
                  as={Link}
                  to='#'
                  renderIcon={ArrowRight16}
                  size='xl'
                  className='right'
                >
                  Request a meeting
                </Button>
              </div>
            </div>
          </Column>
        </Row>
      </Grid>
      <FooterBotm />
    </div>
  );
};

export default CybersecurityLanding;
