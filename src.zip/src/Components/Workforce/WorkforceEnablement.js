import { Button, Column, Grid, Row } from 'carbon-components-react';
import React from 'react';
import MainHeader from '../Homepage/Mainheader/MainHeader';
import BGimage from '../../img/workforce/Mask Group 46.svg';
import cloud from '../../img/workforce/Group 19858.svg';
import chat from '../../img/workforce/chat.png';
import { KeyUsers, DesignResearch } from '@carbon/pictograms-react';
import { ArrowDown16, ArrowLeft16, ArrowRight16 } from '@carbon/icons-react';
import FooterBotm from '../Homepage/Footer/FooterBotm';

const WorkforceEnablement = () => {
  return (
    <div className='workforce'>
      <MainHeader />
      {/* section1 */}
      <Grid
        fullWidth
        className='workforce__banner'
        style={{ backgroundImage: ` url("${BGimage}")` }}
      >
        <Grid condensed>
          <Row className='workforce__banner__content'>
            <Column lg={16} className='pictoIcon'>
              <KeyUsers />
            </Column>
            <Column lg={16} className='heading'>
              <h1>Workforce Enablement</h1>
            </Column>
            <Column lg={7} className='subheading'>
              <p>
                Workforce enablement involves empowering companies to get more
                done while spending less and making more. This involves
                leveraging technology, policies, and principles to make a
                business more productive and efficient. Many businesses are
                still in the process of completing their digitalization. For
                these, workforce enablement offers significant, immediate
                pay-off, as technology is put to work to enhance core systems.
                However, even for companies that already incorporate digital
                tools to drive and support operations, workforce enablement
                provides them with a fresh look at business problems, as well as
                the tools needed to address them.
              </p>
            </Column>
            <Column lg={16} className='learn__more'>
              <Button renderIcon={ArrowDown16}>Learn more</Button>
            </Column>
            <Column className='bottom__arrows'>
              <p>
                <ArrowLeft16 /> Technology Services
              </p>
              <p>
                <span>|</span>
              </p>
              <p>
                up next: cybersecurity <ArrowRight16 />
              </p>
            </Column>
          </Row>
        </Grid>
      </Grid>
      {/* section2 */}
      <Grid fullWidth className='workforce__benifits'>
        <Grid condensed>
          <Row>
            <Column lg={16}>
              <h2>Benefits of Workforce Enablement</h2>
            </Column>
          </Row>
          <Row className='workforce__benifits__box'>
            <Column>
              <div className='heading'>
                <div className='number__box'>
                  <span>1</span>
                </div>
                <h4>More efficient </h4>
              </div>
              <div className='border__line'></div>
              <p>
                By re-examining how the business operates through a
                technological lens, workforce enablement reveals ways for the
                business to earn more while investing less. This may involve
                re-designing systems—or making relatively minor tweaks—using
                digital tools.
              </p>
            </Column>
            <Column>
              <div className='heading'>
                <div className='number__box'>
                  <span>2</span>
                </div>
                <h4>More efficient workforce</h4>
              </div>
              <div className='border__line'></div>
              <p>
                Employees can get buried in technology. Workforce enablement
                often plays the role of providing multiple solutions in one
                unified system, making it easier for employees to keep track of
                the tech they use to do their jobs. In other situations,
                employees are used to doing certain tasks manually and their
                work could be far easier with the help of automation.
              </p>
            </Column>
            <Column>
              <div className='heading'>
                <div className='number__box'>
                  <span>3</span>
                </div>
                <h4>Cost savings</h4>
              </div>
              <div className='border__line'></div>
              <p>
                The right technological solution can open the way for enhancing
                production while consuming fewer resources. Whether it’s funds
                spent supporting the sales team or driving the systems used to
                produce goods or services, workforce enablement focuses on
                finding ways to invest less while getting more.
              </p>
            </Column>
          </Row>
        </Grid>
      </Grid>
      {/* section3 */}
      <Grid fullWidth className='workforce__approach'>
        <Grid condensed>
          <Row>
            <Column lg={8} className='heading'>
              <h2>The Uvation Approach: Deploy, Maintain, Evolve, Secure</h2>
            </Column>
          </Row>
          <Row>
            <Column lg={7} className='subheading'>
              <h6>
                Uvation specializes in an organic, comprehensive approach to
                workforce enablement. This involves four principle initiatives:
              </h6>
            </Column>
          </Row>
          <Row className='approch__box'>
            <Column>
              <div className='pictoIcon'>
                <DesignResearch />
              </div>
              <div className='approch__box__name'>
                <h4>Deploy</h4>
              </div>
              <div className='approch__box__desc'>
                <p>
                  After an in-depth consultative process, Uvation deploys the
                  solution best for your business model.
                </p>
              </div>
            </Column>
            <Column>
              <div className='pictoIcon'>
                <DesignResearch />
              </div>
              <div className='approch__box__name'>
                <h4>Maintain</h4>
              </div>
              <div className='approch__box__desc'>
                <p>
                  You aren’t left to fend for yourself. Uvation maintains the
                  solution, checking to make sure it’s enhancing both the
                  individual user experience and the effectiveness of the
                  business.
                </p>
              </div>
            </Column>
            <Column>
              <div className='pictoIcon'>
                <DesignResearch />
              </div>
              <div className='approch__box__name'>
                <h4>Evolve</h4>
              </div>
              <div className='approch__box__desc'>
                <p>
                  As you change, so must your solution. Uvation stays with you
                  as either you or the business climate change. Whether it’s a
                  gradual shift or a sudden, sharp turn, Uvation makes sure your
                  business enablement tools are up for the challenge.
                </p>
              </div>
            </Column>
            <Column>
              <div className='pictoIcon'>
                <DesignResearch />
              </div>
              <div className='approch__box__name'>
                <h4>Secure</h4>
              </div>
              <div className='approch__box__desc'>
                <p>
                  Uvation has a deep selection of security solutions fit to
                  protect your network and digital asset, regardless of the
                  solution you choose. Further, Uvation can make sure your
                  current systems are adequately protected from cyber threats
                  and disasters.
                </p>
              </div>
            </Column>
          </Row>
        </Grid>
      </Grid>
      {/* section4 */}
      <Grid fullWidth className='workforce__reach'>
        <Grid condensed>
          <Row>
            <Column lg={9} className='workforce__reach__heading'>
              <h2>
                Reach out to Uvation today to see how workforce enablement can
                enhance your business’ performance.
              </h2>
            </Column>
            <Column lg={7} style={{ position: 'relative' }}>
              <img src={BGimage} />
              <div className='bookCons'>
                <p>Book a consultation</p>
              </div>
            </Column>
          </Row>
        </Grid>
      </Grid>
      {/* section5 */}
      <Grid fullWidth className='workforce__drive'>
        <Grid condensed>
          <Row>
            <div className='heading'>
              <h2>What Drives Workforce Enablement?</h2>
            </div>
            <Column lg={8} className='subheading'>
              <p>
                Rather than merely a set of technological solutions, workforce
                enablement involves a mindset focused on improving the way work
                is done and how quickly, as well as aligning systems with
                business goals. This typically involves automation, enabling
                employees, and discovering efficiencies.
              </p>
            </Column>
          </Row>
          <div className='card-col'>
            <div>
              <h3>Incorporate Digital Accountability</h3>
              <p>
                Some may think of digital accountability as an irritation,
                something hanging over employees’ heads, threatening to “tell
                on” them. However, the opposite is the case. Employees enjoy
                tracking their success and seeing how they have improved over
                time. Digital accountability solutions can help make this
                easier. Earnest workers will enjoy solutions that make their
                success demonstrable, tangible, and something they can point to
                when it comes time to negotiate pay increases. For employers and
                managers, digital accountability gives you concrete,
                quantifiable data you can use to connect employee performance
                with factors such as time spent on tasks or the variety of
                methods necessary to close a sale or meet time-based goals.
              </p>
            </div>

            <div>
              <h3>Automate with AI</h3>
              <p>
                Just because a task is easy doesn’t mean it doesn’t hamper
                production. One of the most effective ways to enable the modern
                workforce is to use artificial intelligence to automate
                repetitive or mundane tasks. Automation using simple computer
                logic can go a long way, but artificial intelligence introduces
                the potential for even greater efficiencies. Machine learning
                algorithms can analyze patterns of usage and behavior and then
                make decisions accordingly. For example, an app powered by
                machine learning can use employee work habits to help them
                organize their schedule and get things done on-time—all
                according to settings they can outline to match their personal
                work style. At the same time, managers can tweak settings to
                encourage performance that supports short- and long-term
                objectives.
              </p>
            </div>
            <div>
              <h3>Employee Enablement</h3>
              <p>
                Employees, a business’ greatest asset, can be supported using
                tools that can consolidate their tasks, automate repetitive or
                time-consuming work, and promote digital accountability.
              </p>
            </div>
            <div>
              <h3>Consolidate Daily Activities</h3>
              <p>
                Nearly every business depends a stack of technological tools and
                processes that can easily get overwhelming. Further, juggling
                the different elements of the stack can result in harmful
                inefficiencies. Consolidation can simplify your employees daily
                activities while enhancing productivity. For example, a unified
                communication (UC) system can collapse several methods of
                communication into a single, manageable, simple silo. You can
                combine email, texting, phone calls, video-conferencing, and
                internal file transfer all under one umbrella with a UC system.
                Further, this makes it possible to integrate a customer
                relationship management (CRM) system with your communications
                network. Data regarding when employees reach out to leads and
                other contacts, as well as what was discussed, and how that
                affected movement through the sales funnel can all be tracked,
                classified, and analyzed with a single system.
              </p>
            </div>
            <div>
              <h3>Discover Profit-Driving Efficiencies</h3>
              <p>
                Nearly every system is bogged down by inefficiencies that can be
                remedied using the right technology. One of the simplest, most
                common examples is the management of a building’s energy
                systems. Whether it’s the way the climate is controlled or how
                resources are balanced and managed to support business activity,
                controlling the energy system using software often offers
                instantaneous savings and safety enhancements. The technology
                examines various data points, equipment parameters, and how
                electricity is apportioned and aligns these with efficiency
                requirements. Not only can this save a business significant
                money, the same principles apply to other systems important to
                the organization. For instance, the time and expense associated
                with transporting goods or delivering services can be analyzed.
                Often, this reveals an exorbitant cost of doing business, as
                well as simple ways of making the system more efficient­—and, as
                a result, enhancing profits. This may also involve the resources
                individual employees use to perform their jobs, including time
                spent traveling, and funds spent on food and entertaining
                prospects.
              </p>
            </div>
            <div>
              <h3>Incorporate Digital Accountability</h3>
              <p>
                Some may think of digital accountability as an irritation,
                something hanging over employees’ heads, threatening to “tell
                on” them. However, the opposite is the case. Employees enjoy
                tracking their success and seeing how they have improved over
                time. Digital accountability solutions can help make this
                easier. Earnest workers will enjoy solutions that make their
                success demonstrable, tangible, and something they can point to
                when it comes time to negotiate pay increases. For employers and
                managers, digital accountability gives you concrete,
                quantifiable data you can use to connect employee performance
                with factors such as time spent on tasks or the variety of
                methods necessary to close a sale or meet time-based goals.
              </p>
            </div>
          </div>
        </Grid>
      </Grid>
      {/* section6 */}
      <Grid fullWidth className='workforce__sourcing'>
        <Grid condensed>
          <Row>
            <div className='workforce__sourcing__heading'>
              <h2>Sourcing Technology to Drive Enablement</h2>
            </div>
            <Column className='workforce__sourcing__subheading' lg={9}>
              <p>
                Many of the technologies used in workforce enablement are
                general tools that also improve business in other ways. These
                include cloud and edge computing, both of which can introduce
                novel ways of improving production. Other tools pinpoint
                specific elements of enabling the workforce, such as mobile
                virtualization services and virtual private networks (VPNs).
              </p>
            </Column>
          </Row>
          <Row className='workforce__sourcing__boxrow'>
            <Column lg={8}>
              <div className='workforce__sourcing__imgBox'>
                <img alt='' src={cloud} />
              </div>
            </Column>
            <Column lg={8} style={{ marginBottom: '2rem' }}>
              <div className='workforce__sourcing__card'>
                <div className='heading'>
                  <h3>Workforce Enablement with the Cloud</h3>
                </div>
                <div className='desc'>
                  <p>
                    While the cloud is a powerful storage and processing tool,
                    it can also enhance workforce efficiencies in ways other
                    technologies cannot. While the efficiency benefits are
                    nearly unlimited, here are a few of the most common ways the
                    cloud can make your workforce more productive: · Automatic
                    updates. By shifting your applications and workloads to the
                    cloud, your IT team no longer has to worry about constantly
                    making sure the software your business depends on is
                    up-to-date. Cloud services automatically update their
                    applications and platforms so you always have the latest and
                    most effective versions. <br></br>
                    <br></br>·Eliminate time spent addressing security issues.
                    Using a cloud SaaS or PaaS solution can give you more secure
                    software and platform solutions. This is because cloud-based
                    solutions regularly update their security measures, using
                    the latest firewalls, antivirus, and antimalware
                    technologies. · Grow faster and easier. With the cloud, you
                    can spend less time adding new workstations and software
                    licenses during a growth phase. <br></br> <br></br> A cloud
                    solution can be scaled up in minutes. Each new employee
                    could use their own device and connect to the solution
                    through a secure VPN. Once they connect, they have the
                    software, all necessary dependencies, and operating system
                    ready to go. · Automatically manage backups. <br></br>
                    <br></br>The backup process in many organizations may
                    involve considerable work on the part of the IT team.
                    Whether they have to backup specific groups of workstations,
                    databases pertaining to specific teams, or entire desktops,
                    managing all of it can consume considerable time. With cloud
                    computing, you can have your backups performed
                    automatically. You can designate different backup policies
                    for specific teams at specific times. You can have some data
                    backed up more frequently than others. You can also have
                    some backups performed system-wide while others only execute
                    for certain people or teams.
                  </p>
                </div>
              </div>
            </Column>

            <Column lg={8} style={{ marginBottom: '2rem' }}>
              <div className='workforce__sourcing__card'>
                <div className='heading'>
                  <h3>Workforce Enablement with Edge Computing</h3>
                </div>
                <div className='desc'>
                  <p>
                    With edge computing, you move your computational workload
                    closer to the edge of your company’s network. For many
                    companies, a shift to edge computing significantly enhances
                    their workflows. For example, you can use edge computing to
                    reduce what you spend on bandwidth.<br></br>
                    <br></br> Running an app or streaming data that require
                    low-latency may put a strain on your network, particularly
                    if the computation is all happening in the cloud. As the
                    data flows to where it’s consumed or used in an app, the
                    bandwidth needed to get it there in time may be expensive.
                    However, in many cases, you can use edge computing to run
                    certain processes closer to the edge or onsite,
                    significantly reducing latency. You can use a
                    software-defined wide area network (SD-WAN) or local area
                    network (LAN) to transmit the necessary data to its various
                    destinations.<br></br>
                    <br></br> Because your processing is closer to the point of
                    use—at the edge—you can reduce your monthly expenditure on
                    bandwidth, perhaps only paying for enough for casual
                    internet browsing and periodic cloud backups.
                  </p>
                </div>
              </div>
            </Column>
            <Column lg={8}>
              <div className='workforce__sourcing__imgBox'>
                <img alt='' src={cloud} />
              </div>
            </Column>
            <Column lg={8}>
              <div className='workforce__sourcing__imgBox'>
                <img alt='' src={cloud} />
              </div>
            </Column>
            <Column lg={8} style={{ marginBottom: '2rem' }}>
              <div className='workforce__sourcing__card'>
                <div className='heading'>
                  <h3>Edge Computing for Enablement with Hybrid Cloud</h3>
                </div>
                <div className='desc'>
                  <p>
                    For a business that only uses public cloud, an edge
                    computing approach that incorporates hybrid cloud can both
                    reduce cost and enable faster, more secure processes. With
                    your computing happening at the edge of a network, the
                    devices dependent on the edge workloads can work faster, and
                    you can reduce the attack surface of your network.
                    <br></br> <br></br>
                    For example, you could deploy a local next-generation
                    firewall (NGFW) that protects the edge devices and other
                    on-premise resources of your hybrid cloud network. This
                    allows you to monitor and filter all traffic coming in and
                    going out, as well as open the way for the introduction of
                    other tools like sandboxing and web filtering—all controlled
                    at the edge. Uvation can guide you through figuring out how
                    best to use edge computing to increase efficiencies for your
                    workforce and systems within your workforce. <br></br>{' '}
                    <br></br>With a variety of networking and mobile networking
                    options available, you can take full control of how data
                    moves in support of your employees, their tools and
                    workstations, and business-critical processes.
                  </p>
                </div>
              </div>
            </Column>

            <Column lg={8}>
              <div className='workforce__sourcing__card'>
                <div className='heading'>
                  <h3>Mobile Virtualization</h3>
                </div>
                <div className='desc'>
                  <p>
                    Mobile virtualization services begin by asking the question:
                    “What do our employees need to be successful?” And more
                    specifically, “How can IT support that success?” In the
                    modern business environment, this often involves offering
                    employees ways of being productive while on the road, at
                    home, or in another remote location, such as a co-working
                    space. Mobile virtualization services allow employees to
                    securely access their applications and data from anywhere
                    they want, at any time, and using any device. The objective
                    is to simplify the management, maintenance, and support of
                    any user IT infrastructure. At the same time, mobile
                    virtualization delivers a model that is scalable and
                    flexible. This allows companies to support the use of
                    multiple endpoints, including tablets, laptops, smart
                    phones, and thin clients. This also enables them to weave in
                    their existing applications, infrastructure, and processes.
                    <br /> <br />
                    <h5>Flexible Implementation Options</h5>
                    <br /> You can implement mobile virtualization to empower
                    your workforce in a variety of locations: · On premise · In
                    a collocated facility · In the cloud This means you don’t
                    have to unnecessarily disrupt your current infrastructure if
                    you don’t want to. Also, if your organization is more
                    comfortable with one environment or another, you can deploy
                    a solution within that architecture.,
                    <br /> <br />
                    <h5>Flexible Solutions</h5>
                    <br /> Mobile virtualization can support a
                    bring-your-own-device (BYOD) policy, mobilize your apps,
                    manage your security risks, support branch workers and
                    remote workers, enable contractors to connect and
                    collaborate, reduce the cost of PC refreshes, and support
                    engineers and designers.
                  </p>
                </div>
              </div>
            </Column>
            <Column lg={8}>
              <div className='workforce__sourcing__imgBox'>
                <img alt='' src={cloud} />
              </div>
            </Column>
          </Row>
        </Grid>
      </Grid>
      {/* section7*/}

      <Grid fullWidth className='workforce__chat'>
        <Grid condensed>
          <Row>
            <Column lg={{ span: 7 }}>
              <div className='heading'>
                <h3>
                  Chat with an Uvation expert for a 30-minute strategy session
                  at no cost
                </h3>
              </div>
              <Column lg={10}>
                <div className='subheading'>
                  <p>
                    Get in touch for a consultation call or answer to any
                    questions you might have.
                  </p>
                </div>
              </Column>
            </Column>
            <Column
              lg={{ span: 8, offset: 1 }}
              style={{ position: 'relative' }}
            >
              <div className='imgbox'>
                <img src={chat} alt='' />
              </div>
              <div className='bookCons'>
                <p>Book a consultation</p>
              </div>
            </Column>
          </Row>
        </Grid>
      </Grid>
      <FooterBotm />
    </div>
  );
};

export default WorkforceEnablement;
