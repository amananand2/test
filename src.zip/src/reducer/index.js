import { combineReducers } from 'redux';

import landingPageReducer from "./landingPage"


export const reducers = combineReducers({ landingPageReducer});
